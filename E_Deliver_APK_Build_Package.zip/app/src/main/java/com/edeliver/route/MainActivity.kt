package com.edeliver.route

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Looper
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import kotlin.math.*

data class Parcel(
    val id: Long, var tracking: String, var address: String,
    var priority: Boolean, var lat: Double? = null, var lng: Double? = null,
    var delivered: Boolean = false, var order: Int? = null
)

class MainActivity : ComponentActivity() {
    private lateinit var map: MapView
    private lateinit var tracking: EditText
    private lateinit var address: EditText
    private lateinit var priority: CheckBox
    private lateinit var next: TextView
    private lateinit var list: TextView
    private val parcels = mutableListOf<Parcel>()
    private var riderLat = 14.0
    private var riderLng = 121.0
    private var locationManager: LocationManager? = null
    private var scanDialog: android.app.Dialog? = null

    private val cameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) openScanner() else toast("Camera permission kailangan para mag-scan.") }

    private val locationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) startGps() else toast("Location permission kailangan para sa rider GPS.") }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().load(this, getSharedPreferences("osmdroid", MODE_PRIVATE))
        Configuration.getInstance().userAgentValue = packageName
        setContentView(R.layout.activity_main)

        map = findViewById(R.id.map)
        tracking = findViewById(R.id.tracking)
        address = findViewById(R.id.address)
        priority = findViewById(R.id.priority)
        next = findViewById(R.id.next)
        list = findViewById(R.id.list)

        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setMultiTouchControls(true)
        map.controller.setZoom(13.0)
        map.controller.setCenter(GeoPoint(riderLat, riderLng))

        findViewById<Button>(R.id.btnScan).setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) openScanner()
            else cameraPermission.launch(Manifest.permission.CAMERA)
        }
        findViewById<Button>(R.id.btnAdd).setOnClickListener { addParcel() }
        findViewById<Button>(R.id.btnGps).setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) startGps()
            else locationPermission.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        findViewById<Button>(R.id.btnOptimize).setOnClickListener { optimize() }

        map.setOnClickListener {
            val geo = map.mapCenter
            val p = parcels.firstOrNull { !it.delivered && (it.lat == null || it.lng == null) }
            if (p != null) {
                p.lat = geo.latitude; p.lng = geo.longitude
                toast("Map pin set para ${p.tracking}")
                render()
            }
            true
        }
        render()
    }

    private fun addParcel() {
        val t = tracking.text.toString().trim()
        if (t.isEmpty()) { toast("I-scan o ilagay muna ang tracking number."); return }
        parcels += Parcel(System.currentTimeMillis(), t, address.text.toString().trim(), priority.isChecked)
        tracking.text.clear(); address.text.clear(); priority.isChecked = false
        render()
    }

    private fun openScanner() {
        val dialog = android.app.Dialog(this)
        val preview = PreviewView(this)
        dialog.setContentView(preview)
        dialog.window?.setLayout(-1, -1)
        dialog.show()
        preview.post { dialog.window?.setLayout(-1, -1) }
        scanDialog = dialog

        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val cameraPreview = Preview.Builder().build()
            cameraPreview.setSurfaceProvider(preview.surfaceProvider)
            val scanner = BarcodeScanning.getClient()
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            analysis.setAnalyzer(ContextCompat.getMainExecutor(this)) { proxy ->
                val media = proxy.image
                if (media != null) {
                    val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                    scanner.process(image).addOnSuccessListener { codes ->
                        val value = codes.firstOrNull()?.rawValue
                        if (!value.isNullOrBlank()) {
                            tracking.setText(value)
                            dialog.dismiss()
                            toast("Scanned: $value")
                        }
                    }.addOnCompleteListener { proxy.close() }
                } else proxy.close()
            }
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, cameraPreview, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun startGps() {
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        try {
            locationManager?.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 5f,
                object : LocationListener {
                    override fun onLocationChanged(location: Location) {
                        riderLat = location.latitude; riderLng = location.longitude
                        map.controller.setCenter(GeoPoint(riderLat, riderLng))
                        render()
                    }
                }, Looper.getMainLooper())
            toast("GPS tracking iniciado.")
        } catch (e: SecurityException) { toast("Hindi pinayagan ang Location.") }
    }

    private fun optimize() {
        val pending = parcels.filter { !it.delivered && it.lat != null && it.lng != null }.toMutableList()
        val pri = pending.filter { it.priority }.toMutableList()
        val normal = pending.filter { !it.priority }.toMutableList()
        val ordered = mutableListOf<Parcel>()
        var curLat = riderLat; var curLng = riderLng

        fun takeNearest(list: MutableList<Parcel>) {
            while (list.isNotEmpty()) {
                val p = list.minByOrNull { dist(curLat, curLng, it.lat!!, it.lng!!) }!!
                list.remove(p); ordered += p
                curLat = p.lat!!; curLng = p.lng!!
            }
        }
        takeNearest(pri); takeNearest(normal)
        ordered.forEachIndexed { i, p -> p.order = i + 1 }
        next.text = ordered.firstOrNull()?.let { "🔔 NEXT DELIVERY: #${it.order}\n${it.tracking}\n${it.address}" } ?: "Next Delivery: —"
        render()
    }

    private fun dist(a: Double,b: Double,c: Double,d: Double): Double {
        val x = Math.toRadians(c-a); val y = Math.toRadians(d-b)
        val h = sin(x/2).pow(2) + cos(Math.toRadians(a))*cos(Math.toRadians(c))*sin(y/2).pow(2)
        return 6371.0 * 2 * asin(sqrt(h))
    }

    private fun render() {
        map.overlays.clear()
        val rider = Marker(map); rider.position = GeoPoint(riderLat, riderLng); rider.title = "Rider"; map.overlays.add(rider)
        parcels.filter { it.lat != null && it.lng != null }.forEach {
            val m = Marker(map); m.position = GeoPoint(it.lat!!, it.lng!!); m.title = "#${it.order ?: "•"} ${it.tracking}"
            map.overlays.add(m)
        }
        map.invalidate()
        val ordered = parcels.filter { !it.delivered }.sortedBy { it.order ?: 9999 }
        list.text = if (ordered.isEmpty()) "No pending parcels." else ordered.joinToString("\n\n") {
            "${if (it.order != null) "#${it.order} " else ""}${it.tracking} ${if(it.priority) "🔴 PRIORITY" else ""}\n${it.address}\n${if(it.lat==null) "📍 Tap map to set pin" else "📍 Location set"}"
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    override fun onResume() { super.onResume(); if (::map.isInitialized) map.onResume() }
    override fun onPause() { if (::map.isInitialized) map.onPause(); super.onPause() }
}
